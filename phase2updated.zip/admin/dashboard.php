<?php
include('header.php');
?>
<div id="main">
</div>
<?php
include('footer.php');
?>