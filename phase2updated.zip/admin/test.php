<?php 
include('header.php');
?>
<div id="main">

<?php 
echo "<pre>";
print_r($_SESSION['users']); 
echo "</pre>";
?>
</div>

<?php include('footer.php'); ?>