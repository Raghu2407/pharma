<?php
include('header.php');
$getDetails = $main->getUserDetails(1, $loginType);
// print_r($getDetails);
?>
<div id="main">
    <div class="row">
        <div class="col s12 m12 l12 xl12">
            <table id="page-length-option" class="display">
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>GM Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Username</th>
                        <th>Profile Pic</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 1;
                    if(!empty($getDetails)){
                    foreach($getDetails['Data'] as $gmlists) {
                        $name = $gmlists['Name'];
                        $email = $gmlists['Email'];
                        $phone = $gmlists['Mobile'];
                        $uname = $gmlists['Username'];
                        $profile = $gmlists['Profile'];
                        // $status = $gmlists[''];

                    ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $name ?></td>
                            <td><?= $email ?></td>
                            <td><?= $phone ?></td>
                            <td><?= $uname ?></td>
                            <td><?= $profile ?></td>
                            <td>1</td>
                            <td>2</td>
                        </tr>
                    <?php $i++; } } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>