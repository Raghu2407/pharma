<?php
//session_start();
// include("../include/mrclass.php");
include('../Classes/autoload.php');
$uid = $_SESSION['users']['Data']['UID'];
if(isset($uid))
{
    $page="Logout Page";     
    $field="Logout Successfully.";
    // $mr_class->save_auditlog($page,$field,$_SESSION['doc_name'],$_SESSION['doc_id']); 
	
	session_destroy();
    // unset($_SESSION['doc_id']);
    // unset($_SESSION['doc_name']);
         
    header("Location:index.php");
}


?>

 <script type="text/javascript">
                window.location.href = "index.php";
            </script>