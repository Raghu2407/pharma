<?php
include('header.php');
global $error;
global $errors;
?>
<div id="main">
    <div class="section">
        <div class="row">
            <div class="col s12 m8 l8 xl6 offset-xl3">
                <?php
                if (isset($_POST['submit'])) {
                    include('rsm.php');
                }
                ?>

                <?php
                $GMList = $main->ComptoGM($compid);
                // echo "<pre>";
                // print_r($GMList);
                // echo "</pre>";
                ?>
                <!--form-->
                <p><?= $errors['Message']; ?></p>
                <h5 class="grey-text">Add New ZM</h5>
                <form method="POST">
                    <div class="card">
                        <div class="card-content">
                            <div class="row">

                                <div class="col s12 m6 l6 input-field">
                                    <input type="text" name="name" value="<?= isset($name) ? $name : ''; ?>" required>
                                    <label for="">Name</label>
                                    <?php if (isset($error['name'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['name'];
                                                                } ?></span>
                                </div>
                                <div class="col s12 m6 l6 input-field">
                                    <input type="email" name="email" value="<?= isset($email) ? $email : ''; ?>" required>
                                    <label for="">Email</label>
                                    <?php if (isset($error['email'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['email'];
                                                                } ?></span>
                                </div>
                                <div class="col s12 m6 l4 input-field">
                                    <input type="tel" name="mobile" onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?= isset($mobile) ? $mobile : ''; ?>" required pattern="[6789][0-9]{9}" maxlength="10">
                                    <label for="">Mobile</label>
                                    <?php if (isset($error['mobile'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['mobile'];
                                                                } ?></span>
                                </div>
                                <div class="col s12 m6 l4 input-field">
                                    <input type="text" name="username" value="<?= isset($username) ? $username : ''; ?>" required>
                                    <label for="">Username</label>
                                    <?php if (isset($error['username'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['username'];
                                                                } ?></span>
                                </div>
                                <div class="col s12 m6 l4 input-field">
                                    <input type="password" name="password" value="<?= isset($password) ? $password : ''; ?>" required>
                                    <label for="">password</label>
                                    <?php if (isset($error['password'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['password'];
                                                                } ?></span>
                                </div>
                                <div class="input-field col s12 m6 l6 xl4">
                                    <select id="stateid" name="stateid[]" required>
                                        <option value="">Select State</option>
                                        <?php foreach ($stateId as $states) {

                                            $getStates = $main->GetStateById($states);
                                        ?>
                                            <option value="<?php echo $states; ?>"><?php echo $getStates['StateName']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <label>State</label>
                                </div>
                                <input type="hidden" name="cid" value="<?= $compid; ?>">
                                <input type="hidden" name="type" value="5">
                                <!--input type="hidden" name="-->
                                <div class="input-field col s12 m6 l6 xl4">
                                    <select id="cityid" name="cityid[]" required multiple>
                                        <option value="" disabled selected>Select Cities</option>
                                    </select>
                                    <label>Cities</label>
                                </div>
                                <?php if ($loginType == "4" || $loginType == "5") {
                                    $col = "m6 l6 xl4";
                                ?>
                                    <div class="input-field col s12 <?=$col; ?>">
                                        <select id="uid" name="uid" required>
                                            <option value="">Select GM</option>
                                            <?php foreach ($GMList['Data'] as $GMlists) {
                                            ?>
                                                <option value="<?php echo $GMlists['GID']; ?>"><?php echo $GMlists['Name']; ?></option>
                                            <?php } ?>
                                        </select>
                                        <label>GM</label>
                                    </div>
                                <?php } else { ?>
                                    <input type="hidden" name="uid" value="<?= $uid; ?>">
                                <?php } ?>
                                <div class="input-field col s12">
                                    <textarea id="address" name="address" class="materialize-textarea" required><?= isset($address) ? $address : ''; ?></textarea>
                                    <label for="textarea1">Address</label>
                                    <?php if (isset($error['address'])) {
                                    ?>
                                        <span class="helper-text"><?= $error['address'];
                                                                } ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-action right-align">
                            <button type="submit" class="btn blue" name="submit" id="">
                                Submit
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
<script>
    $(document).ready(function() {
        $('select').formSelect();
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#stateid').on('change', function() {
            var brand_id = $(this).val();
            if (brand_id) {
                $.ajax({
                    type: 'POST',
                    url: 'ajaxCities.php',
                    data: 'brand_id=' + brand_id,
                    success: function(html) {
                        //alert(html);
                        $('#cityid').html(html);
                        $('select').formSelect();
                    }
                });
            } else {
                $('#cityid').html('<option value="">Select States first</option>');
            }
        });
    });
</script>