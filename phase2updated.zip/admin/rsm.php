<?php
$error = [];
if(!isset($_POST['name']) || $_POST['name'] == ""){
    $error['name'] = "filed cannot be blank";
    return;
}else{
    $name = mysqli_real_escape_string($main->con,$_POST['name']);
}
if(!isset($_POST['email']) || $_POST['email'] == " "){
     $error['email'] = "Please enter a valid email";
     return;
}else{
    $email = mysqli_real_escape_string($main->con,$_POST['email']);
}
if(!isset($_POST['mobile']) || $_POST['mobile'] < 10){
    $error['mobile'] = "Mobile No cannot be blank";
    return;
}else{
    $mobile = mysqli_real_escape_string($main->con,$_POST['mobile']);
}

if(!isset($_POST['address']) || $_POST['address'] == ""){
    $error['address'] = "Please add proper address";
    return;
}else{
    $address = mysqli_real_escape_string($main->con,$_POST['address']);
}
$type = $_POST['type'];
$ref = $_POST['uid'];
$zid = $_POST['zid'];
$cid = $_POST['cid'];
$states = $_POST['stateid'];
$cities = $_POST['cityid'];
/* $address= ""; */
$profile = "";
$username = $_POST['username'];
$password = $_POST['password'];

if($errors=$main->validateUser($username,$mobile)['Success'] == "false"){
   switch ($type) {
  case '1'; 
  $add= $main->addGM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,$password,$cid);  
    break ;
    case '2';
    $add= $main->addRSM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,$password,$cid,$zid); 
    break;
    case '3';
    $add= $main->addASM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,$password,$cid,$zid); 
    break;
    case  '5';
    $add = $main->addZM($type, $ref, $states, $cities, $name, $address, $mobile, $email, $profile, $username, $password, $cid); 
    break;
   }
   $errors = $add;
}else{
    $errors = $main->validateUser($username,$mobile);
}


?>