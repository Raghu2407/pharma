
<?php
global $error;
if(isset($_POST['btn_submit']))
{
   include("login_check.php");
}
?><!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="ThemeSelect">
    <title>Hellodoctorz | </title>
    <link rel="apple-touch-icon" href="../../../app-assets/images/favicon/apple-touch-icon-152x152.png">
    <link rel="shortcut icon" type="image/x-icon" href="../../../app-assets/images/favicon/favicon-32x32.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- BEGIN: VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/vendors.min.css">
    <!-- END: VENDOR CSS-->
    <!-- BEGIN: Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/themes/horizontal-menu-template/materialize.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/themes/horizontal-menu-template/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/layouts/style-horizontal.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/pages/login.css">
    <!-- END: Page Level CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/custom/custom.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <style>
        h5 {
            font-family: 'Lato', sans-serif;
        }
        
          body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
  }

  #main {
    flex: 1 0 auto;
  }
  
  input:not([type]):focus:not([readonly]), input[type=text]:not(.browser-default):focus:not([readonly]), input[type=password]:not(.browser-default):focus:not([readonly]), input[type=email]:not(.browser-default):focus:not([readonly]), input[type=url]:not(.browser-default):focus:not([readonly]), input[type=time]:not(.browser-default):focus:not([readonly]), input[type=date]:not(.browser-default):focus:not([readonly]), input[type=datetime]:not(.browser-default):focus:not([readonly]), input[type=datetime-local]:not(.browser-default):focus:not([readonly]), input[type=tel]:not(.browser-default):focus:not([readonly]), input[type=number]:not(.browser-default):focus:not([readonly]), input[type=search]:not(.browser-default):focus:not([readonly]), textarea.materialize-textarea:focus:not([readonly]) {
    border-bottom: 1px solid #2196f3;
    -webkit-box-shadow: 0 1px 0 0 #2196f3;
    box-shadow: 0 1px 0 0 #2196f3;
    box-shadow: 0 1px 0 0 #2196f3;
  }
    input:not([type]):focus:not([readonly]) + label, input[type=text]:not(.browser-default):focus:not([readonly]) + label, input[type=password]:not(.browser-default):focus:not([readonly]) + label, input[type=email]:not(.browser-default):focus:not([readonly]) + label, input[type=url]:not(.browser-default):focus:not([readonly]) + label, input[type=time]:not(.browser-default):focus:not([readonly]) + label, input[type=date]:not(.browser-default):focus:not([readonly]) + label, input[type=datetime]:not(.browser-default):focus:not([readonly]) + label, input[type=datetime-local]:not(.browser-default):focus:not([readonly]) + label, input[type=tel]:not(.browser-default):focus:not([readonly]) + label, input[type=number]:not(.browser-default):focus:not([readonly]) + label, input[type=search]:not(.browser-default):focus:not([readonly]) + label, textarea.materialize-textarea:focus:not([readonly]) + label {
    color: #2196f3;
    
  }
  .input-field .prefix.active {
    color: #2196f3;
}
    </style>
    <!-- END: Custom CSS-->
  </head>
  <!-- END: Head-->
  <body class="blue">
 <div id="main">      
    <div class="row">
      <div class="col s12">
        <div class="container"><div id="login-pages" class="row">
      <div class="col s12 m6 l4 offset-l4 z-depth-4 card-panel border-radius-6 login-card bg-opacity-8">
      <h5><?= $error['error']; ?></h5>
    <form class="login-form" method="post" autocomplete="off">
      <div class="row">
        <div class="input-field col s12 center-align">
        <!--<img width="150px" src="../assets/images/logo/ic_launcher_round.png">-->
          <h5 class="">Login</h5>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="material-icons prefix pt-2">person_outline</i>
          <input id="mobile" name="mobile" id="mobile" type="text">
          <label for="mobile" class="center-align">Username</label>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="material-icons prefix pt-2">lock_outline</i>
          <input id="upass" name="upass" type="password">
          <label for="upass">Password</label>
        </div>
      </div>
       <button type="submit" name="btn_submit" class="btn waves-effect waves-light gradient-45deg-light-blue-cyan col s12">Login <span style="display: inline;
    position: absolute;
    top: 17%;" class="material-icons right">
arrow_forward
</span></button>
      <div class="row">
        <div class="input-field col s12 m12 l12">
          <p class="margin center-align "><a href="Register" class="green-text">Register Now!</a></p>
        </div>
      </div>
    </form>
  </div>
</div>
        </div>
      </div>
    </div>
</div>    
<?php include('footer.php');?>
    <!-- BEGIN VENDOR JS-->
    <script src="../../../app-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="../../../app-assets/js/plugins.js" type="text/javascript"></script>
    <script src="../../../app-assets/js/custom/custom-script.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
  </body>
</html>