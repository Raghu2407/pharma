<html>
  <?php
  include('../Classes/autoload.php');
  if(isset($_SESSION['users'])){
  $uid = $_SESSION['users']['Data']['UID'];
  $compid = $_SESSION['users']['Data']['CID'];
  $stateId = $_SESSION['users']['Data']['States'];
  $loginType = $_SESSION['users']['Data']['Type'];
  }else{
    echo'<script type="text/javascript">
          window.location.href = "index.php";
          </script>';
  }
  
    if($loginType == '4'){
            $list = '
            <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="GM"><i class="material-icons">perm_contact_calendar</i><span>GM<i class="material-icons right">keyboard_arrow_down</i></span></a>
              <ul class="dropdown-content dropdown-horizontal-list type" id="GM">
                <li><a href="addGM.php"><i class="fa fa-circle-o"></i>Add GM</a></li>
                <li><a href="viewGM.php"><i class="fa fa-circle-o"></i>View GM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="ZM"><i class="material-icons">perm_contact_calendar</i><span>ZM<i class="material-icons right">keyboard_arrow_down</i></span></a>
              <ul class="dropdown-content dropdown-horizontal-list type" id="ZM">
                <li><a href="addZM.php"><i class="fa fa-circle-o"></i>Add ZM</a></li>
                <li><a href="viewZM.php"><i class="fa fa-circle-o"></i>View ZM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="RSM"><i class="material-icons">assignment_ind</i><span>RSM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="RSM">
                <li><a href="addRSM.php"><i class="fa fa-circle-o"></i>Add RSM</a></li>
                <li><a href="viewRSM.php"><i class="fa fa-circle-o"></i>View RSM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li class="type<?=$loginType?> type<?=$loginType?>1"><a class="dropdown-menu" href="#" data-target="ASM"><i class="material-icons">perm_contact_calendar</i><span>ASM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="ASM">
                <li><a href="addAsm.php"><i class="fa fa-circle-o"></i>Add ASM</a></li>
                <li><a href="viewASM.php"><i class="fa fa-circle-o"></i>View ASM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="MR"><i class="material-icons">assignment_ind</i><span>Medical Representative<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="MR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="DR"><i class="material-icons">perm_contact_calendar</i><span>Doctors<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="DR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="Products"><i class="material-icons">assignment_ind</i><span>Products<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="Products">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            ';
  }
  else if($loginType == '5'){
            $list = '
            <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="RSM"><i class="material-icons">assignment_ind</i><span>RSM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="RSM">
                <li><a href="addRSM.php"><i class="fa fa-circle-o"></i>Add RSM</a></li>
                <li><a href="viewRSM.php"><i class="fa fa-circle-o"></i>View RSM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li class="type<?=$loginType?> type<?=$loginType?>1"><a class="dropdown-menu" href="#" data-target="ASM"><i class="material-icons">perm_contact_calendar</i><span>ASM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="ASM">
                <li><a href="addAsm.php"><i class="fa fa-circle-o"></i>Add ASM</a></li>
                <li><a href="viewASM.php"><i class="fa fa-circle-o"></i>View ASM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="MR"><i class="material-icons">assignment_ind</i><span>Medical Representative<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="MR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="DR"><i class="material-icons">perm_contact_calendar</i><span>Doctors<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="DR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="Products"><i class="material-icons">assignment_ind</i><span>Products<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="Products">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            ';
  }
  else if($loginType == '1'){
      $list = '
      <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="ZM"><i class="material-icons">perm_contact_calendar</i><span>ZM<i class="material-icons right">keyboard_arrow_down</i></span></a>
              <ul class="dropdown-content dropdown-horizontal-list type" id="ZM">
                <li><a href="addZM.php"><i class="fa fa-circle-o"></i>Add ZM</a></li>
                <li><a href="viewZM.php"><i class="fa fa-circle-o"></i>View ZM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
      <li class="type<?=$loginType?> type<?=$loginType?>1" id="type"><a class="dropdown-menu" href="#" data-target="RSM"><i class="material-icons">assignment_ind</i><span>RSM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="RSM">
                <li><a href="addRSM.php"><i class="fa fa-circle-o"></i>Add RSM</a></li>
                <li><a href="viewRSM.php"><i class="fa fa-circle-o"></i>View RSM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li class="type<?=$loginType?> type<?=$loginType?>1"><a class="dropdown-menu" href="#" data-target="ASM"><i class="material-icons">perm_contact_calendar</i><span>ASM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="ASM">
                <li><a href="addAsm.php"><i class="fa fa-circle-o"></i>Add ASM</a></li>
                <li><a href="viewASM.php"><i class="fa fa-circle-o"></i>View ASM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="MR"><i class="material-icons">assignment_ind</i><span>Medical Representative<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="MR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="DR"><i class="material-icons">perm_contact_calendar</i><span>Doctors<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="DR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="Products"><i class="material-icons">assignment_ind</i><span>Products<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="Products">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>';
  }
  else if($loginType == '2'){
            $list = '<li class="type<?=$loginType?> type<?=$loginType?>1"><a class="dropdown-menu" href="#" data-target="ASM"><i class="material-icons">perm_contact_calendar</i><span>ASM<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="ASM">
                <li><a href="addAsm.php"><i class="fa fa-circle-o"></i>Add ASM</a></li>
                <li><a href="viewASM.php"><i class="fa fa-circle-o"></i>View ASM</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="MR"><i class="material-icons">assignment_ind</i><span>Medical Representative<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="MR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="DR"><i class="material-icons">perm_contact_calendar</i><span>Doctors<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="DR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="Products"><i class="material-icons">assignment_ind</i><span>Products<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="Products">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>';
  }
   else if($loginType == '3'){
            $list = '<li><a class="dropdown-menu" href="#" data-target="MR"><i class="material-icons">assignment_ind</i><span>Medical Representative<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="MR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View MR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="DR"><i class="material-icons">perm_contact_calendar</i><span>Doctors<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="DR">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View DR</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>
            <li><a class="dropdown-menu" href="#" data-target="Products"><i class="material-icons">assignment_ind</i><span>Products<i class="material-icons right">keyboard_arrow_down</i></span></a>
               <ul class="dropdown-content dropdown-horizontal-list" id="Products">
                <li><a href="#"><i class="fa fa-circle-o"></i>Add Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>View Product</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Reports</a></li>
              </ul>
            </li>';
  }
 /*  echo "<pre>";
  print_r($_SESSION['users']);
  echo "</pre>"; */
  /*
  SELECT
  rsm.RID,
  gm.GID,
  asm.*
FROM
  asm
LEFT JOIN
  rsm ON asm.RID = rsm.RID
INNER JOIN
  gm ON rsm.GID = gm.GID
LEFT JOIN
  basic ON asm.ASID = basic.UID
WHERE
  gm.GID = "GID1"
  */
  ?>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <title>HelloDoctorz</title>
  <link rel="apple-touch-icon" href="images/favicon/apple-touch-icon-152x152.png">
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon/favicon-32x32.png">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!-- BEGIN: VENDOR CSS-->
  <link rel="stylesheet" type="text/css" href="../vendors/data-tables/css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="../vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="../vendors/data-tables/css/select.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="../vendors/vendors.min.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/materialize.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/layouts/style-horizontal.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/pages/user-profile-page.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/pages/dashboard.css">
  <link rel="stylesheet" type="text/css" href="css/custom/custom.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/pages/data-tables.css">
  <!--link rel="stylesheet" type="text/css" href="../assets/css/cal.css"-->
  <!-- END: Custom CSS-->
  <style>
    body {
      display: flex;
      min-height: 100vh;
      flex-direction: column;
    }

    #main {
      flex: 1 0 auto;
    }
    
    <?php 
    if($loginType == "4") {
     ?>   
     #type<?=$loginType?>{
         display:block;
     }
     <?php
    }else if(($loginType == "2")){
        $loginType = $loginType + 1;
      if(($loginType != "3")){
        $loginType = $loginType -1;  
        echo ".type".$loginType."{
         display:none;
     }";
      }else{
        echo ".type".$loginType."{
         display:block;
     }";  
      }
     ?>   
     <?php
    }
    ?>
  </style>
</head>

<body class="horizontal-layout page-header-light horizontal-menu 2-columns  " data-open="click" data-menu="horizontal-menu" data-col="2-columns">

  <!-- BEGIN: Header-->
  <header class="page-topbar" id="header">
    <div class="navbar navbar-fixed">
      <nav class="navbar-main navbar-color nav-collapsible sideNav-lock navbar-dark gradient-45deg-light-blue-cyan">
        <div class="nav-wrapper">
          <ul class="left">
            <li>
              <h1 class="logo-wrapper"><a class="brand-logo darken-1" href="index"><img src="../assets/images/logo/ic_launcher_round.png" alt="materialize logo"><span class="logo-text hide-on-med-and-down">HelloDoctorz- <?php echo $uid; ?></span></a></h1>
            </li>
          </ul>
          <!-- <div class="header-search-wrapper hide-on-med-and-down"><i class="material-icons">search</i>
          <input class="header-search-input z-depth-2" type="text" name="Search" placeholder="Explore Materialize">
        </div> -->
          <ul class="navbar-list right">
            <!-- <li class="hide-on-med-and-down"><a class="waves-effect waves-block waves-light translation-button" href="javascript:void(0);" data-target="translation-dropdown"><span class="flag-icon flag-icon-gb"></span></a></li> -->
            <li class="hide-on-med-and-down"><a class="waves-effect waves-block waves-light toggle-fullscreen" href="javascript:void(0);"><i class="material-icons">settings_overscan</i></a></li>
            <li class="hide-on-large-only"><a class="waves-effect waves-block waves-light search-button" href="javascript:void(0);"><i class="material-icons">search </i></a></li>
            <li><a class="waves-effect waves-block waves-light notification-button" href="javascript:void(0);" data-target="notifications-dropdown"><i class="material-icons">notifications_none<small class="notification-badge orange accent-3">5</small></i></a></li>
            <li><a class="waves-effect waves-block waves-light profile-button" href="javascript:void(0);" data-target="profile-dropdown"><span class=""><i class="material-icons">account_circle</i></span></a></li>
          </ul>
          <!-- notifications-dropdown-->
          <ul class="dropdown-content" id="notifications-dropdown">
            <li>
              <h6>NOTIFICATIONS<span class="new badge">5</span></h6>
            </li>
            <li class="divider"></li>
            <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle cyan small">add_shopping_cart</span> A new order has been placed!</a>
              <time class="media-meta" datetime="2015-06-12T20:50:48+08:00">2 hours ago</time>
            </li>
            <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle red small">stars</span> Completed the task</a>
              <time class="media-meta" datetime="2015-06-12T20:50:48+08:00">3 days ago</time>
            </li>
            <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle teal small">settings</span> Settings updated</a>
              <time class="media-meta" datetime="2015-06-12T20:50:48+08:00">4 days ago</time>
            </li>
            <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle deep-orange small">today</span> Director meeting started</a>
              <time class="media-meta" datetime="2015-06-12T20:50:48+08:00">6 days ago</time>
            </li>
            <li><a class="grey-text text-darken-2" href="#!"><span class="material-icons icon-bg-circle amber small">trending_up</span> Generate monthly report</a>
              <time class="media-meta" datetime="2015-06-12T20:50:48+08:00">1 week ago</time>
            </li>
          </ul>
          <!-- profile-dropdown-->
          <ul class="dropdown-content" id="profile-dropdown">
            <li><a class="grey-text text-darken-1" href="user-profile-page.html"><i class="material-icons">person_outline</i> Profile</a></li>
            <li><a class="grey-text text-darken-1" href="app-chat.html"><i class="material-icons">chat_bubble_outline</i> Chat</a></li>
            <li><a class="grey-text text-darken-1" href="page-faq.html"><i class="material-icons">help_outline</i> Help</a></li>
            <li class="divider"></li>
            <li><a class="grey-text text-darken-1" href="user-lock-screen.html"><i class="material-icons">lock_outline</i> Lock</a></li>
            <li><a class="grey-text text-darken-1" href="logout.php"><i class="material-icons">keyboard_tab</i> Logout</a></li>
          </ul>
        </div>

      </nav>
      <!-- BEGIN: Horizontal nav start-->
      <nav class="white hide-on-med-and-down" id="horizontal-nav">
        <div class="nav-wrapper">
          <ul class="left hide-on-med-and-down" id="ul-horizontal-nav" data-menu="menu-navigation">
            <li>
              <a class="dropdown-menus" href="dashboard"><i class="material-icons">dashboard</i><span>Dashboard</span></a>
            
             
            <?php echo $list; ?>
            
          </ul>
        </div>
        <!-- END: Horizontal nav start-->
      </nav>
    </div>
  </header>