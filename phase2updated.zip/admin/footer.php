<!-- Modal Trigger -->
<!-- Modal Structure -->
<footer
    class="page-footer footer footer-static footer-dark gradient-45deg-light-blue-cyan gradient-shadow navbar-border navbar-shadow">
    <div class="footer-copyright">
        <div class="container"><span>&copy;  <a id="year" href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent"
                    target="_blank">HelloDoctorz</a> All rights reserved.</span><span
                class="right hide-on-small-only">Design and Developed by <a
                    href="https://pixinvent.com/">PrakalpaSanika InfoTech</a></span></div>
    </div>
</footer>
<!-- BEGIN VENDOR JS-->
<script src="../assets/js/vendors.min.js" type="text/javascript"></script>
<script src="../assets/js/materialize.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="../vendors/chartjs/chart.min.js"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="../assets/js/plugins.js" type="text/javascript"></script>
<script src="../assets/js/custom/custom-script.js" type="text/javascript"></script>
<script src="../vendors/data-tables/js/jquery.dataTables.min.js" type="text/javascript"></script>
<!-- <script src="../assets/../vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js"
    type="text/javascript"></script> -->
<script src="app-../assets/../vendors/data-tables/js/dataTables.select.min.js" type="text/javascript"></script>
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- <script src="../assets/js/scripts/dashboard-ecommerce.js" type="text/javascript"></script> -->
<!-- END PAGE LEVEL JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="../assets/js/scripts/data-tables.js" type="text/javascript"></script>
<script>
var date = new Date();
var year = date.getFullYear();
document.getElementById("year").innerHTML = year;
</script>
<script type="text/javascript" language="javascript">
    var isMobile = {
        Android: function () {
            return /Android/i.test(navigator.userAgent);
        },
        BlackBerry: function () {
            return /BlackBerry/i.test(navigator.userAgent);
        },
        iOS: function () {
            return /iPhone|iPad|iPod/i.test(navigator.userAgent);
        },
        Windows: function () {
            return /IEMobile/i.test(navigator.userAgent);
        },
        any: function () {
            return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
        }
    };

    if (isMobile.Windows()) {
        window.location = "Windows App Url";
    }
    else if (isMobile.iOS()) {
        window.location = "itune store url";
    }
    else if (isMobile.Android()) {
        window.location = "https://play.google.com/store/apps/details?id=com.cs.mrep&hl=en_IN";
    }
</script>