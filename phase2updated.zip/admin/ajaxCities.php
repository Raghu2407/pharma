  <?php
  include('../Classes/autoload.php');
  $cityId = $_POST['brand_id'];
  $getcities = $main->GetCities($cityId);
  /* print_r($getcities); */
  foreach ($getcities['Data'] as $city){
  ?>
  <option value="<?php echo $city['CityId']; ?>"><?php echo $city['CityName']; ?></option>
  <?php
  }
  ?>