  <?php
    include('../Classes/autoload.php');
    $cityId = $_POST['brand_id'];
    $rsmList = $main->ComptoRSM($cityId);
    /* print_r($getcities); */
    if ($rsmList['Data'] > 0) {
    foreach ($rsmList['Data'] as $rsm) {
            $rsmList['Success']; 
    ?>
      <option value="<?php echo $rsm['RID']; ?>"><?php echo $rsm['Name']; ?></option>
  <?php
    }
    }else{
      ?>
       <option value="" Disabled>No RSM Found</option> 
     <?php   
    }
    ?>