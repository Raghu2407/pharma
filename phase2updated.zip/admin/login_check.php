<?php      
 include("../Classes/autoload.php");   
 error_reporting(E_ALL);
ini_set('display_errors', 1);
  if($_SERVER["REQUEST_METHOD"] == "POST")
  {
      //  $myusername=$_POST['uname'];
        if(!isset($_POST['mobile']) || strlen($_POST['mobile']) < 1){
        $error['error'] = "Please enter valid mobile number";
        return;
        }else{
           $mobile  = mysqli_real_escape_string($main->con,$_POST['mobile']);
        }
        
    
    
      //if($_SESSION['attempt']<3){
          //$error['error'] = "Login access failed due to many of attempts";
        //return;
          $password = $_POST['upass'];
        /* $password=sha1($pass); */
      if(isset($mobile) && $password!="")   
      { 
        $login = $main->adminLoginAuth($mobile,$password);
        if($login['Success']== 'true'){
            $r = $_SESSION['users'] = $login;
            $uid = $r['Data']['UID'];
            header('location:test.php');
        }else{
            $error['error']= "error";
            return;
            //$_SESSION['attempt'] = $_SESSION['attempt'] + 1;
        }
        //$_SESSION['attempt'];
        
     //}
      }
     else{
        $error['error'] ="error";
        return;
         
     }

  }     
  ?>
