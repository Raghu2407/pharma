<?php
require_once("autoload.php");
class utils{
	public function base64E($string){
		return base64_encode($string);
	}

	public function base64D($string){
		return base64_decode($string);
	}


	

	

	




}	

?>