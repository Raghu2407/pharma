<?php
require_once("autoload.php");
class AdminClass extends Utils
{
	public $con;
	private $response;
	
	function __construct()
	{
		$this->con = mysqli_connect("localhost",DBuser,DBpass,Database);
		    if (mysqli_connect_errno()) {
				  echo "Failed to connect to MySQL: " . mysqli_connect_error();
				  exit();
			}
	}


	public function GetStates($countryId){
		$arr=array();
		$res=mysqli_query($this->con,"SELECT `name` as StateName, `id` as StateId 
									FROM `states` WHERE `country_id`='$countryId'");
		if(mysqli_num_rows($res) > 0){
			while($result=mysqli_fetch_assoc($res)){
				array_push($arr, $result);
			}	
			$response['Success']="true";
			$response['Message']="States Avilable";
			$response['Data']=$arr;
		}else{
			$response['Success']="false";
			$response['Message']="No States Avilable";
		}
		return $response;
	}

	public function GetCities($stateId){
		$arr=array();
		$res=mysqli_query($this->con,"SELECT `id` as CityId, `name` as CityName 
									FROM `cities` WHERE `state_id`='$stateId'");
		if(mysqli_num_rows($res) > 0){
			while($result=mysqli_fetch_assoc($res)){
				array_push($arr, $result);
			}	
			$response['Success']="true";
			$response['Message']="Cities Avilable";
			$response['Data']=$arr;
		}else{
			$response['Success']="false";
			$response['Message']="No City Avilable";
		}
		return $response;	
	}

	public function GetStateById($stateId){
		$res=mysqli_query($this->con,"SELECT `name` as StateName 
									FROM `states` WHERE `id`='$stateId'");
		$response=mysqli_fetch_assoc($res);
		return $response;
	}

	public function GetCityById($cityId){
		$res=mysqli_query($this->con,"SELECT `name` as CityName 
									FROM `cities` WHERE `id`='$cityId'");
		$response=mysqli_fetch_assoc($res);
		return $response;	
	}

	public function adminLoginAuth($username,$password){
		$username=mysqli_real_escape_string($this->con,$username);
		$password=mysqli_real_escape_string($this->con,$password);
		$res=mysqli_query($this->con,"SELECT * FROM `creds` 
												WHERE `Username`= '$username' and `Password` = '$password'")or die(mysqli_error($this->con));
		if(mysqli_num_rows($res) == 1){
			$result=mysqli_fetch_assoc($res);
			$response['Success']="true";
			$response['Message']="";
			$response['Data']=$this->fetchBasicDetails($result['Type'],$result['UID']);
		}else{
			$response['Success']="false";
			$response['Message']="Login Failed";
		}
		 return $response;
	}

	public function fetchBasicDetails($type,$uid){
		$states=array();
		$cities=array();
		switch ($type) {
			case '1':
				  $sql="SELECT
							  `g`.`CID` AS `REF`,
							  `g`.`GID` AS `UID`,
							  `g`.`CID` AS CID,
							  `b`.`Name`,
							  `b`.`Email`,
							  `b`.`Mobile`,
							  `b`.`Address`,
							  `b`.`Profile`,
							  `a`.`CityId`,
							  `a`.`StateId`
							FROM
							  `gm` AS `g`
							JOIN
							  `basic` AS `b`
							ON
							  `b`.`UID` = `g`.`GID`
							JOIN
							  `areas` AS `a`
							ON
							  `a`.`UID` = `g`.`GID`
							WHERE
							  `g`.`GID` = '$uid'";
				 		break;
			case '2':
				$sql="SELECT
						  `g`.`GID` AS REF,
						  `g`.`RID` AS UID,
						  `g`.`CID` AS CID,
						  `b`.`Name`,
						  `b`.`Email`,
						  `b`.`Mobile`,
						  `b`.`Address`,
						  `b`.`Profile`,
						  `a`.`CityId`,
						  `a`.`StateId`
						FROM
						  rsm AS `g`
						JOIN
						  `basic` AS `b`
						ON
						  `b`.`UID` = `g`.`RID`
						JOIN
						  areas AS `a`
						ON
						  `a`.`UID` = `g`.`RID`
						WHERE
						  `g`.`RID` = '$uid'";
				break;
			case '3':
				$sql="SELECT
					  `g`.`RID` AS REF,
					  `g`.`ASID` AS UID,
					  `g`.`CID` AS CID,
					  `b`.`Name`,
					  `b`.`Email`,
					  `b`.`Mobile`,
					  `b`.`Address`,
					  `b`.`Profile`,
					  `a`.`CityId`,
					  `a`.`StateId`
					FROM
					  asm AS `g`
					JOIN
					  `basic` AS `b`
					ON
					  `b`.`UID` = `g`.`ASID`
					JOIN
					  areas AS `a`
					ON
					  `a`.`UID` = `g`.`ASID`
					WHERE
					  `g`.`ASID` = '$uid'";
				break;

			case '4':
				$sql="SELECT 
							`p1`.`CID` as CID,
							`p1`.`cName` as Name, 
							`p1`.`cAddress` as Address, 
							`p1`.`cEmail` as Email, 
							`p1`.`cMobile` as Mobile,
							`p2`.`AID` as REF,
							`p2`.`StatesId` as StateId 
											FROM 
											`pharacompany` as `p1` JOIN `pharma_admin1` as `p2` 
											ON `p1`.`CID` = `p2`.`CID` 
														WHERE `p1`.`CID` = '$uid'";
				break;
			case '5':
				$sql = "SELECT
						  `g`.`GID` AS REF,
						  `g`.`ZID` AS UID,
						  `g`.`CID` AS CID,
						  `b`.`Name`,
						  `b`.`Email`,
						  `b`.`Mobile`,
						  `b`.`Address`,
						  `b`.`Profile`,
						  `a`.`CityId`,
						  `a`.`StateId`
						FROM
						  ZM AS `g`
						JOIN
						  `basic` AS `b`
						ON
						  `b`.`UID` = `g`.`ZID`
						JOIN
						  areas AS `a`
						ON
						  `a`.`UID` = `g`.`ZID`
						WHERE
						  `g`.`ZID` = '$uid'";
				break;					
		}
			$res=mysqli_query($this->con,$sql)or die(mysqli_error($this->con));
			while($result=mysqli_fetch_assoc($res)){
				if($type != "4"){
					$response['Profile']=$result['Profile'];
					$response['UID']=$result['UID'];
					array_push($cities,$result['CityId']);	
				}else{
					$response['UID']=$result['CID'];
				}
				$response['CID']=$result['CID'];
				$response['REF']=$result['REF'];
				$response['Name']=$result['Name'];
				$response['Email']=$result['Email'];
				$response['Mobile']=$result['Mobile'];
				$response['Address']=$result['Address'];
				
				array_push($states,$result['StateId']);
				
			}
			$response['Type']=$type;
			$response['States']=$states;
			$response['Cities']=$cities;
		return $response;
	}

	public function addUser($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,
							$password,$cid){
		switch ($type) {
			case '1':
				$response=$this->addGM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,
										$username,$password,$cid);
				break;
			case '2':
				$response=$this->addASM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,
										$username,$password,$cid);
				break;
			case '3':
				$response=$this->addRSM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,$password,$cid,$zid);
				break;
			case '5':
				$response = $this->addZM($type, $ref, $states, $cities, $name, $address, $mobile, $email, $profile, $username, $password, $cid);
				//$response=$this->addGSM();
				break;
		}
		return $response;
	}

	public function addGM($type,$ref,$states,$cities,$name,$address,$mobile,$email,$profile,$username,$password,$cid){
		$sql = "INSERT INTO `gm` (`AID`, `CID`, `GID`)VALUES ('$ref', '$cid','')";									
		$res=mysqli_query($this->con, $sql);
		if($res){
			$id=mysqli_insert_id($this->con);
			$uid=GM."-".$id;
			if(mysqli_query($this->con,"UPDATE `gm` SET `GID` = '$uid' WHERE `gm`.`Id` = '$id'")){
				if($this->addBasics($uid,$name,$address,$mobile,$email,$profile,$type)){
					$this->addAreas($uid,$states,$cities,$type);
					$this->addCreds($uid,$type,$username,$password);
				}else{
					$response['Success']='false';
					$response['Message']='Basics Error..';
				}	
			}else{
				$response['Success']='false';
				$response['Message']='UID ERROR..';
			}			
		}else{
			$response['Success']='false';
			$response['Message']='Insert Error';
		}
		$response['Success']='true';
		$response['Message']='User Created Successfully..';
		return $response;
	}


	public function addZM(
		$type,
		$ref,
		$states,
		$cities,
		$name,
		$address,
		$mobile,
		$email,
		$profile,
		$username,
		$password,
		$cid
	) {
		$res = mysqli_query($this->con, "INSERT INTO `ZM` 
									(`ZID`, `GID`, `CID`) 
									VALUES 
									('', '$ref', '$cid')");
		if ($res) {
			$id = mysqli_insert_id($this->con);
			$uid = ZM . "-" . $id;
			if (mysqli_query($this->con, "UPDATE `ZM` SET `ZID` = '$uid' WHERE `zm`.`Id` = '$id'")) {
				if ($this->addBasics($uid, $name, $address, $mobile, $email, $profile, $type)) {
					$this->addAreas($uid, $states, $cities, $type);
					$this->addCreds($uid, $type, $username, $password);
				} else {
					$response['Success'] = 'false';
					$response['Message'] = 'Basics Error..';
				}
			} else {
				$response['Success'] = 'false';
				$response['Message'] = 'UID ERROR..';
			}
		} else {
			$response['Success'] = 'false';
			$response['Message'] = 'Insert Error';
		}
		$response['Success'] = 'true';
		$response['Message'] = 'User Created Successfully..';
		return $response;
	}

	public function addRSM($type,$ref,$states,$cities,
							$name,$address,$mobile,$email,$profile,
							$username,$password,$cid,$zid){
		$res=mysqli_query($this->con,"INSERT INTO `rsm` 
									(`RID`, `GID`, ZID, `CID`) 
									VALUES 
									('', '$ref', '$zid', '$cid')");
		if($res){
			$id=mysqli_insert_id($this->con);
			$uid=RSM."-".$id;
			if(mysqli_query($this->con,"UPDATE `rsm` SET `RID` = '$uid' WHERE `rsm`.`Id` = '$id'")){
				if($this->addBasics($uid,$name,$address,$mobile,$email,$profile,$type)){
					$this->addAreas($uid,$states,$cities,$type);
					$this->addCreds($uid,$type,$username,$password);
				}else{
					$response['Success']='false';
					$response['Message']='Basics Error..';
				}	
			}else{
				$response['Success']='false';
				$response['Message']='UID ERROR..';
			}			
		}else{
			$response['Success']='false';
			$response['Message']='Insert Error';
		}
		$response['Success']='true';
		$response['Message']='User Created Successfully..';	
		return $response;
	}

	public function addASM($type,$ref,$states,$cities,$name,$address,
							$mobile,$email,$profile,
							$username,$password,$cid){
		 $sql = "INSERT INTO `asm` 
								(`ASID`, `RID`, `CID`) 
									VALUES('', '$ref', '$cid')";						
		$res=mysqli_query($this->con,$sql);
		if($res){
			$id=mysqli_insert_id($this->con);
			$uid=ASM."-".$id;
			if(mysqli_query($this->con,"UPDATE `asm` SET `ASID` = '$uid' WHERE `asm`.`Id` = '$id'")){
				if($this->addBasics($uid,$name,$address,$mobile,$email,$profile,$type)){
					$this->addAreas($uid,$states,$cities,$type);
					$this->addCreds($uid,$type,$username,$password);
				}else{
					$response['Success']='false';
					$response['Message']='Basics Error..';
				}	
			}else{
				$response['Success']='false';
				$response['Message']='UID ERROR..';
			}			
		}else{
			$response['Success']='false';
			$response['Message']='Insert Error';
		}
			$response['Success']='true';
			$response['Message']='User Created Successfully..';	
			return $response;
	}


	public function addBasics($uid,$name,$address,$mobile,$email,$profile,$type){
		if(mysqli_query($this->con,"INSERT INTO `basic` 
										(`Name`, `UID`, `Type`, `Email`, `Mobile`, `Address`, `Profile`) 
									VALUES 
										('$name', '$uid', '$type', '$email', '$mobile', '$address', '')")){
			return true;	
		}else{
			return false;
		}
	}
	
	public function addCreds($uid,$type,$username,$password){
		$sql = "INSERT
				INTO
				  `creds`(
					`UID`,
					`Type`,
					`Username`,
					`Password`
				  )
				VALUES('$uid','$type','$username','$password')";
		mysqli_query($this->con,$sql);
	}

	public function addAreas($uid,$states,$cities,$type){
			foreach($cities as $key=> $city){
				for($i=0; $i<count($states); $i++){
			$sql =	"INSERT INTO `areas` 
										(`CityId`, `StateId`, `UID`, `Type`) 
									 VALUES 
									 	('$cities[$key]', '$states[$i]', '$uid', '$type')";
			mysqli_query($this->con,$sql);
				}
		}
		
	}

	public function validateUser($username,$mobile){
				$sql1="SELECT * FROM `basic` WHERE `Mobile`='$mobile'";
				$sql2="SELECT * FROM `creds` WHERE `Username`='$username'";

				$res1=mysqli_query($this->con,$sql1);
				$res2=mysqli_query($this->con,$sql2);
				if(mysqli_num_rows($res1) > 0){
					$result['Success']="true";
					$result['Message']="Mobile Already Exists";					
				}elseif(mysqli_num_rows($res2) > 0){
					$result['Success']="true";
					$result['Message']="Username Already Taken..";
					/* $result['error']="Username Already Taken.."; */
				}else{
					$result['Success']="false";
					$result['Message']="You May Proceed..";
				}
				return $result;
	}


	public function getUserDetails($type,$loginType)
	{
		$data = array();
		switch ($type) {
			case '1':
			$sql = "SELECT t1.GID as UID,t1.CID as REF,t1.CID,t2.Name,t2.Type,t2.Email,t2.Mobile,t2.Address,t2.Profile,t3.Username,t3.Password,t3.LastLogin FROM gm as t1 JOIN basic t2 ON t1.GID=t2.UID JOIN creds as t3 ON t1.GID=t3.UID";
				break;

			case '2':
				$sql = "SELECT t1.RID as UID,t1.GID as REF,t1.CID,t2.Name,t2.Type,t2.Email,t2.Mobile,t2.Address,t2.Profile,t3.Username,t3.Password,t3.LastLogin FROM rsm as t1 JOIN basic t2 ON t1.RID=t2.UID JOIN creds as t3 ON t1.RID=t3.UID";
				break;

			case '3':
				$sql = "SELECT t1.ASID as UID,t1.RID as REF,t1.CID,t2.Name,t2.Type,t2.Email,t2.Mobile,t2.Address,t2.Profile,t3.Username,t3.Password,t3.LastLogin FROM asm as t1 JOIN basic t2 ON t1.ASID=t2.UID JOIN creds as t3 ON t1.ASID=t3.UID";
				break;

			case '4':
				$sql = "SELECT t1.ASID as UID,t1.RID as REF,t1.CID,t2.Name,t2.Type,t2.Email,t2.Mobile,t2.Address,t2.Profile,t3.Username,t3.Password,t3.LastLogin FROM asm as t1 JOIN basic t2 ON t1.ASID=t2.UID JOIN creds as t3 ON t1.ASID=t3.UID";
				break;
			case '5':
				$sql = "SELECT t1.ZID as UID,t1.GID as REF,t1.CID,t2.Name,t2.Type,t2.Email,t2.Mobile,t2.Address,t2.Profile,t3.Username,t3.Password,t3.LastLogin FROM zm as t1 JOIN basic t2 ON t1.ZID=t2.UID JOIN creds as t3 ON t1.ZID=t3.UID";
				break;	
			}
				$res = mysqli_query($this->con, $sql);
				if (mysqli_num_rows($res) > 0) {
					while ($result = mysqli_fetch_assoc($res)) {
						$data[] = $result;
					}
					$response['Success'] = 'true';
					$response['Message'] = 'Data Found..';
					$response['Data'] = $data;
				} else {
					$response['Success'] = 'false';
					$response['Message'] = 'No Data Found..';
					$response['Data'] = '[]';
				}
		return $response;
		
	}

	//Who u r,wts ur id, What u want(id),if he is ur junior wts his id
	public function getReference($uid, $type, $reqType, $reqUid)
	{
		switch ($reqType) {
			case '1':
				$response = $this->getData($uid, GM_T, $reqUid);
				break;

			case '2':
				$response = $this->getData($uid, RSM_T, $reqUid);
				break;

			case '3':
				$response = $this->getData($uid, ASM_T, $reqUid);
				break;

			case '4':
				//$response=$this->getData($uid,GM_T,$reqUid);
				break;
				
			case '5':
				$response = $this->getData($uid, ZM_T, $reqUid);
				break;	
		}
	}

	public function getData($uid, $tablename, $id, $field)
	{
		$temp = array();
		echo $sql = "SELECT * FROM 
		$tablename as t1 JOIN basic as t2 ON `t1`.`$field` = `t2`.`UID` 
						WHERE $field='$id'";
		$res = mysqli_query($this->con, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
	}

	public function ComptoGM($uid)
	{
		$temp = array();
		$sql = "SELECT * FROM gm as t1 JOIN basic as t2 ON `t1`.`GID` = `t2`.`UID` WHERE CID='$uid'";
		$res = mysqli_query($this->con, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
		return $response;
	}

	public function ComptoRSM($uid)
	{
		$temp = array();
		$sql = "SELECT * FROM rsm as t1 JOIN basic as t2 ON `t1`.`RID` = `t2`.`UID` WHERE `t1`.`GID`='$uid'";
		$res = mysqli_query($this->con, $sql);
		if(mysqli_num_rows($res)){
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
	}else{
			$response['Data'] = 0;
			$response['Success'] = "true";
	}
		return $response;
	}

	public function gmToRsm($uid)
	{
		$temp = array();
		$sql = "SELECT * FROM rsm as t1 JOIN basic as t2 ON `t1`.`RID` = `t2`.`UID` WHERE GID='$uid'";
		$res = mysqli_query($this->con, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
		return $response;
	}
	
	public function zmToRsm($uid)
	{
		$temp = array();
		$sql = "SELECT * FROM rsm as t1 JOIN basic as t2 ON `t1`.`RID` = `t2`.`UID` WHERE ='$uid'";
		$res = mysqli_query($this->con, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
		return $response;
	}
	

	public function gmToAsm($uid)
	{
		$temp = array();
		echo $sql = "SELECT t1.*,t2.* FROM asm AS t1  LEFT JOIN rsm AS t3 ON t1.RID = t3.RID LEFt JOIN gm as t4 ON t3.GID=t4.GID LEFt JOIN basic AS t2 ON `t1`.`ASID` = `t2`.`UID` WHERE t4.GID = '$uid'";
		$res = mysqli_query($this->con, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$temp[] = $result;
		}
		$response['Data'] = $temp;
		$response['Success'] = "true";
		return $response;
	}
	

	








}
?>	