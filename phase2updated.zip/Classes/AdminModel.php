<?php
	class AdminModel{
		private $CID;
		private $adminName;
		private $adminAddress;
		private $adminStates[];
		private $adminEmail;
		private $adminMobile;



    /**
     * @return mixed
     */
    public function getCID()
    {
        return $this->CID;
    }



    /**
     * @return mixed
     */
    public function getAdminName()
    {
        return $this->adminName;
    }

    /**
     * @return mixed
     */
    public function getAdminAddress()
    {
        return $this->adminAddress;
    }

    
}
?>