<?php
 
define("Database", "pharma");
define("DBuser", "root");
define("DBpass", ""); 

define("GM", "GM");
define("ZM", "ZM");
define("RSM", "RSM");
define("ASM", "ASM");
define("PID", "PID");

/* Tables */
define("GM_T", "gm");
define("RSM_T", "rsm");
define("ASM_T", "asm");
define("MR_T","");


?>