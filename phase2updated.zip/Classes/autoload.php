<?php
session_start();
	// Hooks
	include("Constants.php");
	include("Utils.php");
	include("AdminClass.php");
	// include("AdminModel.php");
	

	// Objects
	$main=new AdminClass();
	// $adminModel=new AdminModel();
?>